import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.formData()

    const name = body.get("name") as string
    const email = body.get("email") as string
    const subject = body.get("subject") as string
    const message = body.get("message") as string

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json({ message: "Please fill in all required fields." }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ message: "Please enter a valid email address." }, { status: 400 })
    }

    // For now, we'll simulate sending an email
    // In production, you would integrate with an email service like:
    // - Resend (recommended for Next.js)
    // - SendGrid
    // - Nodemailer with SMTP
    // - EmailJS

    console.log("Contact form submission:", {
      name,
      email,
      subject,
      message,
      timestamp: new Date().toISOString(),
    })

    // Simulate email sending delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // For demonstration, we'll always return success
    // In production, you'd handle actual email sending here
    return NextResponse.json({ message: "Thank you! Your message has been sent successfully." }, { status: 200 })
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json({ message: "Something went wrong. Please try again later." }, { status: 500 })
  }
}
