"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Code,
  Palette,
  Mic,
  GraduationCap,
  Users,
  Award,
  ExternalLink,
  Mail,
  Phone,
  Linkedin,
  Github,
  ChevronDown,
  Star,
  MapPin,
  Menu,
  X,
  ArrowUp,
  Send,
  Megaphone,
  ClapperboardIcon as ChalkboardTeacher,
  Loader2,
  Hand,
} from "lucide-react"
import Image from "next/image"

export default function Portfolio() {
  const [activeSection, setActiveSection] = useState("home")
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [typingText, setTypingText] = useState("")
  const [wordIndex, setWordIndex] = useState(0)
  const [charIndex, setCharIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [formStatus, setFormStatus] = useState({ message: "", isSuccess: false, isVisible: false })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isFanned, setIsFanned] = useState(false)
  const [cardDropState, setCardDropState] = useState<"stacked" | "dropping" | "revealed">("stacked")
  const [droppedCards, setDroppedCards] = useState<number[]>([])

  const words = ["Developer", "Artist", "Speaker", "Educator", "Yoga Enthusiast"]
  const nameRef = useRef<HTMLDivElement>(null)
  const contactFormRef = useRef<HTMLFormElement>(null)

  const images = [
    { src: "/images/walkwithbag.jpg", alt: "Campus Life" },
    { src: "/images/speaker.jpg", alt: "Public Speaking" },
    { src: "/images/mypaintings.jpg", alt: "Artistic Work" },
    { src: "/images/parasailing.jpg", alt: "Adventure Spirit" },
  ]

  // Typing animation effect
  useEffect(() => {
    const timeout = setTimeout(
      () => {
        const currentWord = words[wordIndex]

        if (!isDeleting && charIndex < currentWord.length) {
          setTypingText(currentWord.substring(0, charIndex + 1))
          setCharIndex(charIndex + 1)
        } else if (isDeleting && charIndex > 0) {
          setTypingText(currentWord.substring(0, charIndex - 1))
          setCharIndex(charIndex - 1)
        } else {
          setIsDeleting(!isDeleting)
          if (!isDeleting) {
            setWordIndex((wordIndex + 1) % words.length)
          }
        }
      },
      isDeleting ? 50 : 100,
    )

    return () => clearTimeout(timeout)
  }, [charIndex, isDeleting, wordIndex, words])

  // Scroll effects
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY
      setIsScrolled(scrollY > 50)
      setShowBackToTop(scrollY > 300)

      // Update active section
      const sections = ["home", "about", "experience", "projects", "services", "contact"]
      const scrollPosition = scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }

      // Animate elements on scroll
      const animateElements = document.querySelectorAll(".animate-on-scroll")
      animateElements.forEach((element) => {
        const elementPosition = element.getBoundingClientRect().top
        const screenPosition = window.innerHeight / 1.2

        if (elementPosition < screenPosition) {
          element.classList.add("animate-visible")
        }
      })
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Enhanced name animation interactions with performance optimization
  useEffect(() => {
    const nameContainer = nameRef.current
    if (!nameContainer) return

    // Force GPU acceleration for performance
    const parts = nameContainer.querySelectorAll(".name-part")
    parts.forEach((part: Element) => {
      const element = part as HTMLElement
      element.style.transform = "translate3d(0,0,0)"
    })

    const handleClick = () => {
      parts.forEach((part: Element) => {
        const element = part as HTMLElement
        element.style.animation = "none"
        void element.offsetWidth // Trigger reflow

        if (element.classList.contains("pragyensh")) {
          element.style.animation = "quickFloatPart 1.8s cubic-bezier(0.2, 0.8, 0.4, 1) forwards"
        } else if (element.classList.contains("pritiman")) {
          element.style.animation = "quickFloatPart 1.8s cubic-bezier(0.2, 0.8, 0.4, 1) 0.15s forwards"
        } else if (element.classList.contains("panda")) {
          element.style.animation = "quickFloatPart 1.8s cubic-bezier(0.2, 0.8, 0.4, 1) 0.3s forwards"
        }
      })
    }

    nameContainer.addEventListener("click", handleClick)

    return () => {
      nameContainer.removeEventListener("click", handleClick)
    }
  }, [])

  // Handle contact form submission
  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!contactFormRef.current) return

    setIsSubmitting(true)
    setFormStatus({ message: "", isSuccess: false, isVisible: false })

    try {
      const formData = new FormData(contactFormRef.current)

      const response = await fetch("/api/contact", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      setFormStatus({
        message: data.message,
        isSuccess: response.ok,
        isVisible: true,
      })

      if (response.ok) {
        contactFormRef.current.reset()
      }
    } catch (error) {
      console.error("Form submission error:", error)
      setFormStatus({
        message: "Network error. Please try again later.",
        isSuccess: false,
        isVisible: true,
      })
    } finally {
      setIsSubmitting(false)

      // Hide message after 5 seconds
      setTimeout(() => {
        setFormStatus((prev) => ({ ...prev, isVisible: false }))
      }, 5000)
    }
  }

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMenuOpen(false)
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const triggerCardDrop = () => {
    if (cardDropState !== "stacked") return

    setCardDropState("dropping")
    setDroppedCards([])

    // Sequential card dropping with delays
    setTimeout(() => setDroppedCards([1]), 300)
    setTimeout(() => setDroppedCards([1, 2]), 800)
    setTimeout(() => setDroppedCards([1, 2, 3]), 1300)
    setTimeout(() => setDroppedCards([1, 2, 3, 4]), 1800)

    // Mark as fully revealed
    setTimeout(() => setCardDropState("revealed"), 2000)

    // Stack back together after showing all cards
    setTimeout(() => {
      setCardDropState("stacked")
      setDroppedCards([])
    }, 4000)
  }

  return (
    <div className="min-h-screen bg-slate-900 text-gray-200 overflow-x-hidden">
      {/* Navigation */}
      <header
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled ? "bg-slate-900/90 backdrop-blur-md py-4 shadow-lg" : "bg-transparent py-6"
        }`}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <a href="#home" className="text-2xl font-bold text-white">
            Pragyensh<span className="text-cyan-400">.</span>
          </a>

          <nav className={`hidden md:flex space-x-8`}>
            {["Home", "About", "Experience", "Projects", "Services", "Contact"].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className={`relative font-medium transition-colors duration-300 hover:text-cyan-400 ${
                  activeSection === item.toLowerCase() ? "text-cyan-400" : "text-gray-300"
                }`}
              >
                {item}
                <span
                  className={`absolute -bottom-1 left-0 h-0.5 bg-cyan-400 transition-all duration-300 ${
                    activeSection === item.toLowerCase() ? "w-full" : "w-0"
                  }`}
                ></span>
              </button>
            ))}
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-gray-300 hover:text-cyan-400 transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden absolute top-full left-0 w-full bg-slate-800/95 backdrop-blur-md transition-all duration-300 ${
            isMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
          }`}
        >
          <nav className="flex flex-col items-center py-8 space-y-4">
            {["Home", "About", "Experience", "Projects", "Services", "Contact"].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="text-gray-300 hover:text-cyan-400 transition-colors font-medium"
              >
                {item}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-slate-900 to-cyan-900/20"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(192,36,177,0.15)_0%,rgba(18,18,18,1)_70%)]"></div>

        <div className="container mx-auto px-6 grid md:grid-cols-2 gap-12 items-center z-10 relative">
          {/* Left Content */}
          <div className="space-y-6 relative">
            <h3 className="text-xl font-medium text-gray-300 animate-fade-in-up delay-100">Hi, I'm</h3>

            {/* Quick Name Container with Optimized Animation */}
            <div
              ref={nameRef}
              className="quick-name-container relative h-40 md:h-48 overflow-visible cursor-pointer"
              style={{ perspective: "1000px" }}
            >
              <div className="name-part pragyensh font-montserrat font-black text-4xl md:text-5xl lg:text-6xl leading-none mb-2">
                Pragyensh
              </div>
              <div className="name-part pritiman font-montserrat font-black text-3xl md:text-4xl lg:text-5xl leading-none mb-2">
                Pritiman
              </div>
              <div className="name-part panda font-montserrat font-black text-3xl md:text-4xl lg:text-5xl leading-none">
                Panda
              </div>
            </div>

            <h3 className="text-2xl font-semibold animate-fade-in-up delay-200 relative z-20">
              And I'm a <span className="text-cyan-400 font-bold">{typingText}</span>
              <span className="animate-pulse">|</span>
            </h3>
            <p className="text-lg text-gray-300 leading-relaxed animate-fade-in-up delay-300 relative z-20">
              Creating impact through code, creativity, and connection.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4 animate-fade-in-up delay-400 relative z-20">
              <Button
                onClick={() => scrollToSection("projects")}
                className="bg-cyan-400 hover:bg-cyan-500 text-slate-900 font-semibold px-8 py-3 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-400/25"
              >
                Explore My Work
              </Button>
              <Button
                onClick={() => scrollToSection("contact")}
                variant="outline"
                className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-slate-900 font-semibold px-8 py-3 rounded-full transition-all duration-300 hover:scale-105"
              >
                Hire Me
              </Button>
            </div>
          </div>

          {/* Right Image with Enhanced Float */}
          <div className="relative flex justify-center">
            <div className="relative w-80 h-96 animate-enhanced-float">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-2xl blur-xl opacity-30 animate-pulse-glow"></div>
              <Image
                src="/images/pragyensh-profile.jpg"
                alt="Pragyensh Pritiman Panda"
                width={320}
                height={384}
                className="relative z-10 w-full h-full object-cover rounded-2xl shadow-2xl animate-image-entrance gpu-accelerated"
              />
            </div>
          </div>
        </div>

        <button
          onClick={() => scrollToSection("about")}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gray-400 hover:text-cyan-400 transition-colors animate-bounce-delayed"
        >
          <ChevronDown size={32} />
        </button>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-white">
            About Me
            <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mt-4 rounded-full"></div>
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="relative animate-on-scroll">
              <div
                className="card-deck-container relative w-80 h-96 mx-auto cursor-pointer"
                style={{ perspective: "1000px" }}
              >
                {/* Click Hint */}
                <div className="click-hint absolute -top-8 left-1/2 transform -translate-x-1/2 text-cyan-400 text-sm font-medium opacity-80 animate-pulse pointer-events-none flex items-center gap-2">
                  <Hand size={16} />
                  {cardDropState === "stacked" ? "Click to reveal cards" : "Watch the reveal..."}
                </div>

                {/* Card Deck */}
                <div
                  className="card-deck relative w-full h-full transform-gpu"
                  onClick={triggerCardDrop}
                  style={{ transformStyle: "preserve-3d" }}
                >
                  {/* Card 1 (Top) - Walking with bag */}
                  <div
                    className={`card card-1 absolute w-full h-full rounded-2xl overflow-hidden shadow-2xl transition-all duration-700 ease-out transform-gpu ${droppedCards.includes(1) ? "dropped" : ""}`}
                  >
                    <Image
                      src="/images/walkwithbag.jpg"
                      alt="Campus Life"
                      width={320}
                      height={384}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900/90 to-transparent p-4">
                      <p className="text-white text-sm font-medium">Campus Life</p>
                    </div>
                  </div>

                  {/* Card 2 - Speaker */}
                  <div
                    className={`card card-2 absolute w-full h-full rounded-2xl overflow-hidden shadow-2xl transition-all duration-700 ease-out transform-gpu ${droppedCards.includes(2) ? "dropped" : ""}`}
                  >
                    <Image
                      src="/images/speaker.jpg"
                      alt="Public Speaking"
                      width={320}
                      height={384}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900/90 to-transparent p-4">
                      <p className="text-white text-sm font-medium">Public Speaking</p>
                    </div>
                  </div>

                  {/* Card 3 - Paintings */}
                  <div
                    className={`card card-3 absolute w-full h-full rounded-2xl overflow-hidden shadow-2xl transition-all duration-700 ease-out transform-gpu ${droppedCards.includes(3) ? "dropped" : ""}`}
                  >
                    <Image
                      src="/images/mypaintings.jpg"
                      alt="Artistic Work"
                      width={320}
                      height={384}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900/90 to-transparent p-4">
                      <p className="text-white text-sm font-medium">Artistic Work</p>
                    </div>
                  </div>

                  {/* Card 4 (Bottom) - Parasailing */}
                  <div
                    className={`card card-4 absolute w-full h-full rounded-2xl overflow-hidden shadow-2xl transition-all duration-700 ease-out transform-gpu ${droppedCards.includes(4) ? "dropped" : ""}`}
                  >
                    <Image
                      src="/images/parasailing.jpg"
                      alt="Adventure Spirit"
                      width={320}
                      height={384}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900/90 to-transparent p-4">
                      <p className="text-white text-sm font-medium">Adventure Spirit</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6 animate-on-scroll">
              <h3 className="text-2xl font-semibold text-white">Developer, Artist, Speaker & Educator</h3>
              <div className="space-y-4 text-gray-300 leading-relaxed">
                <p>
                  Hi, I'm Pragyensh Pritiman Panda — a creator, developer, speaker, and educator with a passion for
                  building things that make a difference.
                </p>
                <p>
                  Currently pursuing my B.Tech in Computer Science at Amity University, Greater Noida, I thrive at the
                  intersection of technology, creativity, and human connection. Whether I'm leading innovation at my
                  college's tech community Fusion Tech, crafting intuitive web and app solutions, or painting life onto
                  a blank canvas, my mission remains the same — to leave every space better than I found it.
                </p>
                <p>
                  Beyond the screen, I've mentored over 250 students in Science and English, won national-level art
                  awards, clinched state medals in yoga and athletics, and proudly held the title of Mr. AUGN and Head
                  Boy at my previous institution. From hosting IEEE conferences to spearheading live projects like
                  DineWise and Rentastic, I bring energy, empathy, and excellence into every role I take on.
                </p>
                <p>This portfolio is a window into the many hats I wear — and I'm just getting started.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {[
                  { icon: GraduationCap, text: "B.Tech CSE, Amity University" },
                  { icon: Phone, text: "+91 XXXXX XXXXX" },
                  { icon: Mail, text: "princepragyensh@gmail.com" },
                  { icon: MapPin, text: "Greater Noida, India" },
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-cyan-400" />
                    <span className="text-gray-300">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-white">
            My Journey
            <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mt-4 rounded-full"></div>
          </h2>

          <div className="max-w-4xl mx-auto relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-cyan-400 hidden md:block"></div>

            {[
              {
                date: "2023 - Present",
                title: "R&D Head @ Fusion Tech Club",
                description:
                  "Leading research and development initiatives for the university's tech club, organizing hackathons and workshops.",
                icon: Code,
              },
              {
                date: "2023 - Present",
                title: "Student Ambassador @ Unstop",
                description:
                  "Representing the platform at my university, promoting competitions and opportunities to fellow students.",
                icon: Users,
              },
              {
                date: "2022 - Present",
                title: "Speaker & Host at IEEE Events",
                description:
                  "Regularly speaking at technical events and hosting college functions with audiences of 200+ people.",
                icon: Mic,
              },
              {
                date: "2023",
                title: "DineWise Project Lead",
                description: "Developed a smart mess management system for college campuses to reduce food waste.",
                icon: Award,
              },
              {
                date: "2020 - 2023",
                title: "Private Tutor (250+ students)",
                description:
                  "Taught Science and English to school students with proven track record of improved grades.",
                icon: GraduationCap,
              },
              {
                date: "2019 - 2020",
                title: "Former Head Boy & Mr. AUGN",
                description: "Demonstrated leadership skills and won the prestigious Mr. AUGN title in my school.",
                icon: Star,
              },
            ].map((item, index) => (
              <div
                key={index}
                className={`relative flex items-center mb-12 animate-on-scroll ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                <div className={`w-full md:w-5/12 ${index % 2 === 0 ? "md:text-right md:pr-8" : "md:pl-8"}`}>
                  <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-400/10">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="text-cyan-400 mt-1">
                          <item.icon size={24} />
                        </div>
                        <div className="flex-1">
                          <div className="text-cyan-400 font-semibold mb-2">{item.date}</div>
                          <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                          <p className="text-gray-300 leading-relaxed">{item.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-cyan-400 rounded-full border-4 border-slate-900"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-white">
            My Projects
            <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mt-4 rounded-full"></div>
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "DineWise Campus Hub",
                description:
                  "Smart mess management system for college campuses to reduce food waste and optimize meal planning.",
                tags: ["Web App", "AI Integration"],
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Rentastic",
                description:
                  "Hyperlocal rental service app connecting people who need items with those who have them to rent.",
                tags: ["Mobile App", "Flutter"],
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Personal Portfolio",
                description: "A responsive portfolio website showcasing my skills, projects and experience.",
                tags: ["HTML/CSS", "JavaScript"],
                image: "/placeholder.svg?height=400&width=600",
              },
            ].map((project, index) => (
              <Card
                key={index}
                className="bg-slate-800/50 border-slate-700 overflow-hidden group hover:border-cyan-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-400/10 animate-on-scroll"
              >
                <div className="relative overflow-hidden">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    width={600}
                    height={400}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">{project.title}</h3>
                  <p className="text-gray-300 mb-4 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} className="bg-cyan-400/20 text-cyan-400 hover:bg-cyan-400/30">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-4">
                    <Button size="sm" className="bg-cyan-400 hover:bg-cyan-500 text-slate-900">
                      <ExternalLink size={16} className="mr-2" />
                      Live Demo
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-slate-900"
                    >
                      <Github size={16} className="mr-2" />
                      Code
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-white">
            My Services
            <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mt-4 rounded-full"></div>
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Code,
                title: "Website/App Development",
                description:
                  "Custom digital solutions tailored to your needs, built with modern technologies and best practices.",
              },
              {
                icon: Palette,
                title: "Self-Portrait Commissions",
                description:
                  "Hand-drawn personalized portraits that capture personality and emotion in unique artistic style.",
              },
              {
                icon: Megaphone,
                title: "Influencer Collaborations",
                description: "Brand promotions and partnerships leveraging my audience and public speaking platforms.",
              },
              {
                icon: ChalkboardTeacher,
                title: "Online Tutoring",
                description: "Personalized Science and English lessons for school students with proven results.",
              },
            ].map((service, index) => (
              <Card
                key={index}
                className="bg-slate-800/50 border-slate-700 p-6 text-center group hover:border-cyan-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-400/10 animate-on-scroll"
              >
                <CardContent className="p-0">
                  <div className="text-cyan-400 mb-6 flex justify-center group-hover:scale-110 transition-transform duration-300">
                    <service.icon size={48} />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-4">{service.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section with Enhanced Form */}
      <section id="contact" className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-white">
            Get In Touch
            <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mt-4 rounded-full"></div>
          </h2>

          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-semibold text-white mb-4">Let's Build Something Meaningful Together</h3>
                <p className="text-gray-300 text-lg leading-relaxed">
                  Feel free to reach out for collaborations or just to say hello!
                </p>
              </div>

              <div className="space-y-6">
                {[
                  {
                    icon: Mail,
                    title: "Email",
                    value: "princepragyensh@gmail.com",
                    href: "mailto:princepragyensh@gmail.com",
                  },
                  { icon: Phone, title: "Phone", value: "+91 XXXXX XXXXX", href: "tel:+91XXXXXXXXXX" },
                  {
                    icon: Linkedin,
                    title: "LinkedIn",
                    value: "linkedin.com/in/pragyensh",
                    href: "https://linkedin.com/in/pragyensh",
                  },
                ].map((contact, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-cyan-400/20 rounded-full flex items-center justify-center">
                      <contact.icon className="w-6 h-6 text-cyan-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">{contact.title}</h4>
                      <a href={contact.href} className="text-gray-300 hover:text-cyan-400 transition-colors">
                        {contact.value}
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-8">
                <div className="contact-form">
                  <form ref={contactFormRef} onSubmit={handleContactSubmit} className="space-y-6">
                    <div className="form-group relative">
                      <input
                        type="text"
                        id="name"
                        name="name"
                        className="form-control w-full bg-slate-700/50 border border-slate-600 rounded-md px-4 py-3 text-white focus:border-cyan-400 focus:outline-none transition-all duration-300 peer pt-6"
                        placeholder=" "
                        required
                      />
                      <label
                        htmlFor="name"
                        className="form-label absolute text-sm text-gray-400 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3"
                      >
                        Your Name
                      </label>
                    </div>

                    <div className="form-group relative">
                      <input
                        type="email"
                        id="email"
                        name="email"
                        className="form-control w-full bg-slate-700/50 border border-slate-600 rounded-md px-4 py-3 text-white focus:border-cyan-400 focus:outline-none transition-all duration-300 peer pt-6"
                        placeholder=" "
                        required
                      />
                      <label
                        htmlFor="email"
                        className="form-label absolute text-sm text-gray-400 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3"
                      >
                        Your Email
                      </label>
                    </div>

                    <div className="form-group relative">
                      <input
                        type="text"
                        id="subject"
                        name="subject"
                        className="form-control w-full bg-slate-700/50 border border-slate-600 rounded-md px-4 py-3 text-white focus:border-cyan-400 focus:outline-none transition-all duration-300 peer pt-6"
                        placeholder=" "
                        required
                      />
                      <label
                        htmlFor="subject"
                        className="form-label absolute text-sm text-gray-400 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3"
                      >
                        Subject
                      </label>
                    </div>

                    <div className="form-group relative">
                      <textarea
                        id="message"
                        name="message"
                        className="form-control w-full bg-slate-700/50 border border-slate-600 rounded-md px-4 py-3 text-white focus:border-cyan-400 focus:outline-none transition-all duration-300 min-h-[120px] peer pt-6"
                        placeholder=" "
                        required
                      ></textarea>
                      <label
                        htmlFor="message"
                        className="form-label absolute text-sm text-gray-400 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3"
                      >
                        Your Message
                      </label>
                    </div>

                    <button
                      type="submit"
                      className={`w-full bg-cyan-400 hover:bg-cyan-500 text-slate-900 font-semibold py-3 px-6 rounded-md transition-all duration-300 flex items-center justify-center ${isSubmitting ? "opacity-70 cursor-not-allowed" : ""}`}
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 size={16} className="mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send size={16} className="mr-2" />
                          Send Message
                        </>
                      )}
                    </button>

                    {formStatus.isVisible && (
                      <div
                        className={`form-message mt-4 p-3 rounded-md text-center transition-all duration-300 ${
                          formStatus.isSuccess ? "bg-cyan-400/20 text-cyan-400" : "bg-red-400/20 text-red-400"
                        }`}
                      >
                        {formStatus.message}
                      </div>
                    )}
                  </form>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-slate-900 border-t border-slate-700">
        <div className="container mx-auto px-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="flex space-x-6">
              {[
                { icon: Github, href: "#" },
                { icon: Linkedin, href: "#" },
                { icon: Mail, href: "mailto:princepragyensh@gmail.com" },
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center text-gray-400 hover:text-cyan-400 hover:bg-slate-700 transition-all duration-300 hover:scale-110"
                >
                  <social.icon size={20} />
                </a>
              ))}
            </div>
            <p className="text-gray-400 text-center">
              © {new Date().getFullYear()} Pragyensh Pritiman Panda. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 w-12 h-12 bg-cyan-400 text-slate-900 rounded-full flex items-center justify-center shadow-lg hover:bg-cyan-500 transition-all duration-300 hover:scale-110 z-50"
        >
          <ArrowUp size={20} />
        </button>
      )}
    </div>
  )
}
